<?php
session_start();
include 'conexion.php';

$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];

    $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE nombre_usuario = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $fila = $res->fetch_assoc();

        // Comparación directa (sin hash, solo para entorno local)
        if ($contrasena === $fila['contrasena']) {
    $_SESSION['id_gimnasio'] = $fila['id_gimnasio'];
    $_SESSION['usuario'] = $fila['nombre_usuario']; // 🔥 Esta línea faltaba
    header("Location: index.php");
    exit();
}
    } else {
        $mensaje = "Usuario no encontrado.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - Multi Gimnasio</title>
</head>
<body style="background:#111; color:#fff; font-family:Arial; padding:40px;">
    <?php if ($mensaje): ?>
        <p style="color: red;"><?php echo $mensaje; ?></p>
    <?php endif; ?>

    <h2>Login</h2>
    <form method="post">
        Usuario:<br>
        <input type="text" name="usuario" required><br><br>
        Contraseña:<br>
        <input type="password" name="contrasena" required><br><br>
        <input type="submit" value="Ingresar">
    </form>
</body>
</html>
