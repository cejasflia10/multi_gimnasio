<?php
include("conexion.php");

// Obtener datos del formulario
$usuario = $_POST['nombre_usuario'];
$contrasena = $_POST['contrasena'];
$id_gimnasio = $_POST['id_gimnasio'];

// Obtener los permisos (1 si está marcado, 0 si no)
$puede_ver_clientes = isset($_POST['puede_ver_clientes']) ? 1 : 0;
$puede_ver_membresias = isset($_POST['puede_ver_membresias']) ? 1 : 0;
$puede_ver_profesores = isset($_POST['puede_ver_profesores']) ? 1 : 0;
$puede_ver_ventas = isset($_POST['puede_ver_ventas']) ? 1 : 0;
$puede_ver_admin = isset($_POST['puede_ver_admin']) ? 1 : 0;

// Insertar en la base de datos
$sql = "INSERT INTO usuarios (nombre_usuario, contrasena, id_gimnasio,
         puede_ver_clientes, puede_ver_membresias, puede_ver_profesores, puede_ver_ventas, puede_ver_admin)
        VALUES ('$usuario', '$contrasena', '$id_gimnasio',
         $puede_ver_clientes, $puede_ver_membresias, $puede_ver_profesores, $puede_ver_ventas, $puede_ver_admin)";

if ($conexion->query($sql) === TRUE) {
    echo "Usuario registrado correctamente.";
    header("Location: ver_usuarios.php");
} else {
    echo "Error al registrar usuario: " . $conexion->error;
}

$conexion->close();
?>
